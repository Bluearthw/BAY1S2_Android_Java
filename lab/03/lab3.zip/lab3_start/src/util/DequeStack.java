package util;

public class DequeStack<T> implements StackIntf<T>
{
}
