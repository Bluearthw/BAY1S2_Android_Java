package application;

public interface BracketParserIntf {

	public abstract boolean checkBrackets(String text);

}