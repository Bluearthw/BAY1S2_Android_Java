package application;

import util.StackIntf;
import util.DequeStack;

public class BracketParser implements BracketParserIntf
{
    @Override
    public boolean checkBrackets(String text)
    {
        //TO BE IMPLEMENTED
        return false;
    }
}
